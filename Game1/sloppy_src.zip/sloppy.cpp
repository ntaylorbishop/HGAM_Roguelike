
#include "stdafx.h"

#ifdef XWIN32
static double btime() { static bool inited = false; static DWORD clk0; if (!inited) { inited = true; clk0 = GetTickCount(); return 0.0; } return (GetTickCount() - clk0)*0.001; }
#define WSTR_SPEC L"%s"
const wchar_t WPATHDELIM = L'\\';
#ifdef max
#undef max
#endif
#else

#define XUNIX
#include <vector>
#include <stack>
#include <map>
#include <string>
#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <cassert>
#include <algorithm>
#include <glob.h>
#include <wchar.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>

#define WSTR_SPEC L"%ls"
const wchar_t WPATHDELIM = L'/';

static double btime() {static bool inited = false;static int secs, usecs;struct timeval tv;if (!inited) {inited = true;gettimeofday(&tv, NULL);secs = tv.tv_sec;usecs = tv.tv_usec;return 0.0;}gettimeofday(&tv, NULL);return tv.tv_sec - secs + (tv.tv_usec - usecs)*0.000001;}

#ifndef uchar
#define uchar uchar
typedef unsigned char uchar;

#endif // uchar

#endif

using namespace std;

#ifdef XUNIX
// include functions to convert wstring to utf8 and vice versa:
#include "unicode_convert.h"
#endif

struct SrcFile;

struct Token
{
    string *name;
    SrcFile *sf;
    int line;
    int lastsametoken;
    bool isdecl;
};

vector<Token> tokens;
map<string, int> lasttokstringlocs;

struct SrcFile
{
    wstring fn;
    uchar *src;
    wstring fnonly;
    int len;

    SrcFile(FILE *fh, wstring _fn, size_t _len, const wchar_t*_fnonly) : fn(_fn), src(new uchar[_len + 1]), fnonly(_fnonly)
    {
        len = _len;
        memset(src, 0, len + 1);
        fread(src, 1, len, fh);
    }
    ~SrcFile()
    {
			delete[] src;
	}

    uchar *p;
    uchar *namestart;
    Token tok;
    const char *separators;
    int nest;
    int lasttldeclarator;
    stack<bool> decllevel;

    void NewTok()
    {
        string s(namestart, p);
        auto it = lasttokstringlocs.find(s);
        if (it==lasttokstringlocs.end())
        {
            auto itbool = lasttokstringlocs.insert(make_pair(s, tokens.size()));
            it = itbool.first;
        }
        else
        {

            tok.lastsametoken = it->second;
            it->second = tokens.size();
        }

        tok.name = (string *)&it->first;
        tok.isdecl = decllevel.size() == 0 || decllevel.top();
        tokens.push_back(tok);
    }

    // correctly tokenizes C++ that compiles :)
    void Tokenize()
    {
        p = src;
        tok.sf = this;
        tok.line = 1;
        tok.lastsametoken = -1;
        separators = "()[]{},;";
        while (decllevel.size()) decllevel.pop();
        int lasttldeclarator = -1;

        for(;;)
        {
            namestart = p;
            uchar c = *p++;

            if (!c) return; // eof

            if (c == '\n') { tok.line++; continue; }

            if (c <= ' ' || c > '~') continue;  // FIXME: maybe should support unicode idents?

            if (c == 'L' && (*p == '\"' || *p == '\'')) c = *p++;
            if (c == '\"' || c == '\'')     // strings with quotation escape
            {
                uchar delim = c;
                while (*p >= ' ' && (*p != delim || *(p-1) == '\\')) p++;
                if (*p == delim) p++;
                NewTok();
                continue;
            }

            if (isalpha(c) || c == '_')
            {
                while (isalnum(*p) || *p == '_') p++;
                NewTok();
                int len = p - namestart;
                if (len > 3 && (*tok.name == "class" ||
                                *tok.name == "struct" ||
                                *tok.name == "interface" || 
                                *tok.name == "namespace" ||
                                *tok.name == "enum")) lasttldeclarator = tokens.size() - 1;
                continue;
            }

            if (isdigit(c) || (c == '.' && isdigit(*p)))
            {
                while (isalnum(*p) || *p=='.') p++;  // dec, hex, hex-prefix, floats & exponents, suffixes
                NewTok();
                continue;
            }

            if (c == '/')   // comments
            {
                if (*p == '/')
                {
                    while (*p && *p != '\n') p++;
                    continue;
                }
                else if (*p == '*')
                {
                    p++;
                    while (*p && (*p != '*' || *(p+1) != '/'))
                    {
                        if (*p == '\n') tok.line++;
                        p++;
                    }
                    if (*p) p += 2;
                    continue;
                }
            }

            assert(ispunct(c));

            if (strchr(separators, c))
            {
                NewTok();
                if (c == '{') { decllevel.push(lasttldeclarator >= 0 && tok.line - tokens[lasttldeclarator].line < 2); lasttldeclarator = -1; }
                else if (c == '}' && decllevel.size()) decllevel.pop();
                continue;
            }

            // collect operator symbols
            while (ispunct(*p) && *p != '_' && (*p != '.' || !isdigit(*(p+1))) && !strchr(separators, *p)) p++;

            uchar last = *(p-1);
            if (last == '=' || last == '>') { NewTok(); continue; }    // any assignment and comparison ops

            bool same = true;
            for(uchar *q = namestart + 1; q < p; q++) same = same && *q == *namestart;
            if (same) { NewTok(); continue; }      // all double ops like == && <<

            // assume they are separate ops
            uchar *end = p;
            p = namestart + 1;
            for(;;)
            {
                NewTok();
                if (p == end) break;
                tok.name++;
                p++;
            }
        }
    }
};

vector<SrcFile *> files;
bool recurse = true;
vector<wstring> excludes;
const wchar_t *customext = L"";

bool should_exclude(const wchar_t* filename)
{
	for (auto it = excludes.begin(); it != excludes.end(); ++it) {
		if (wcsstr(filename, it->c_str())) return true;
	}
	return false;
}

void scan(const wstring &folder)
{
    wprintf(L"scanning folder " WSTR_SPEC L"\n", folder.c_str());

    #ifdef XWIN32

    WIN32_FIND_DATA fdata;
    HANDLE fh = FindFirstFile((folder + L"*.*").c_str(), &fdata);
    if(fh != INVALID_HANDLE_VALUE)
    {
        do 
        {
			wstring cFileName = fdata.cFileName;
			wstring xFileName = folder + cFileName;
			bool isDir = (fdata.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0;
			int nFileSizeLow = fdata.nFileSizeLow;

    #else

	glob_t gl;
	wstring mask = folder + L"/*";
	char temp[512];
	convert_wide_to_utf8(mask, temp);
	int globerror = glob(temp, GLOB_MARK | GLOB_TILDE, NULL, &gl);
	if (!globerror) {
		for (size_t fi = 0; fi < gl.gl_pathc; fi++) {
			wstring xFileName = convert_utf8_to_wide(gl.gl_pathv[fi]);
			bool isDir = xFileName[xFileName.length()-1] == L'/';
			if (isDir) xFileName = xFileName.substr(0, xFileName.length() - 1);
			wstring cFileName = xFileName.substr(xFileName.find_last_of(L'/') + 1);
			int nFileSizeLow;
			struct stat st;
			stat(gl.gl_pathv[fi], &st);
			nFileSizeLow = (int) st.st_size;

    #endif

            if (!should_exclude(cFileName.c_str()))
            {
                if (isDir)
                {
                    wstring subf = cFileName;
                    if (recurse && subf != L"." && subf != L"..") scan(folder + subf + WPATHDELIM);
                }
                else
                {
                    wstring fn = folder + cFileName;
                    size_t pos = fn.find_last_of(L'.');
                    if (pos != wstring::npos)
                    {
                        wstring ext = fn.substr(pos + 1);
                        transform(ext.begin(), ext.end(), ext.begin(), towlower);
                        if (ext == L"cpp" || ext == L"h" || ext == L"cxx" || ext == L"c" || ext == L"cc" || ext == L"inl" || ext == L"hpp" ||
                            ext == L"cs" || ext == L"java" || ext == L"js" || ext == L"php" || ext == L"m" || ext == L"as" || ext == L"fx" ||
                            ext == L"py" || ext == L"rb" || ext == L"pl" || ext == L"lua" || ext == customext)
                        {
                            bool equal = false;
                            for (auto it = files.begin(); it != files.end(); ++it) {
                                SrcFile* sf = *it;
                                if (sf->len == nFileSizeLow && sf->fnonly == cFileName) equal = true;
                            };

                            if(equal)
                            {
                                wprintf(L"file " WSTR_SPEC L" is identical to a file already loaded, skipping...\n", fn.c_str());
                            }
                            else
                            {
                                #ifdef XWIN32
                                FILE *fh = _wfopen(fn.c_str(), L"rb");
                                #else
                                FILE *fh = fopen(gl.gl_pathv[fi], "rb");
                                #endif
                                if (fh)
                                {
                                    files.push_back(new SrcFile(fh, fn, nFileSizeLow, cFileName.c_str()));
                                    fclose(fh);

                                    wprintf(L"read " WSTR_SPEC L" (%d)\n", fn.c_str(), nFileSizeLow);
                                }
                                else
                                {
                                    wprintf(L"file " WSTR_SPEC L" unreadable?\n", fn.c_str());
                                }
                            }
                        }
                    }
                }
            }
        #ifdef XWIN32
        } while(FindNextFile(fh, &fdata));
        #else
		}
		globfree(&gl);
        #endif
    }
    #ifdef XWIN32
    FindClose(fh);
    #endif
}

struct Match
{
    Token a, b;
    double bad;
    int len;
    int start;
    int tokenskips;
};



int _tmain(int argc, wchar_t* argv[])
{
    int maxworst = 10;
    wstring basefolder = L"";

    wprintf(L"Sloppy - code analysis tool by Wouter van Oortmerssen\n\nloading files:\n\n");
    for (int i = 1; i < argc; i++)
    {
        if (argv[i][0] == '-')
        {
            switch (argv[i][1])
            {
                case 'o': {
					swscanf(argv[i] + 2, L"%d", &maxworst);
					maxworst = max(min(maxworst, 100), 0);
					break;
				}
                case 'r': recurse = false; break;
                case 'e': excludes.push_back(wstring(&argv[i][2])); break;
                case 'c': customext = &argv[i][2]; break;
                default: wprintf(L"unknown command line option: " WSTR_SPEC L"\n", argv[i]);
            }
        }
        else
        {
            basefolder = argv[i];
            if (basefolder[basefolder.size()-1] != WPATHDELIM) basefolder += WPATHDELIM;
            scan(basefolder);
        }
    }

    if (!basefolder.size()) scan(basefolder);

	for (auto it = files.begin(); it != files.end(); ++it) (*it)->Tokenize();

    if (!tokens.size())
    {
        wprintf(L"\nno code found!\n\n");
        getchar();
        return 1;
    }

    /*
    FILE *tfh = fopen("tokendump.txt", "w");
    for_each(tokens.begin(), tokens.end(), [&](Token &tok)
    {
        string t = tok.Str();
        fprintf(tfh, "%s ", t.c_str());
        if (t == ";") fprintf(tfh, "\n");
    });
    fclose(tfh);
    */

    vector<Match> worst;
    map<int, pair<int, double>> freqs;
    int cur = 0;
    int max = tokens.size();
    double totalbad = 0;
    int progress = 1;
    const double progressamount = 10000000000.0;
    Match bestmatch;

    wprintf(L"\nmatching...");
    double starttime = btime();

    while (cur < max - 2)
    {
        if (cur*(double)cur > progressamount*progress) { wprintf(L" %.1f%%", cur*(double)cur*100/max/max); fflush(stdout); progress++; }
        bestmatch.bad = 0;

        for (int match = tokens[cur].lastsametoken; match >= 0; match = tokens[match].lastsametoken)
        {
            if (tokens[match + 1].name != tokens[cur + 1].name) continue;

            int decltokens = 0;
            int bodytokens = 0;
            int curstart = cur;
            int firstmismatch = 0;
            int tokenskips = 0;
            int lastfullmatchstart = cur;
            int biggestfullmatch = 0;
            int matchstart = match;

            for(;;)
            {
                (tokens[cur].isdecl ? decltokens : bodytokens)++;

                match++;
                cur++;

                if (match >= curstart || cur >= max) break;

                if (tokens[match].name != tokens[cur].name)
                {
                    if (!firstmismatch) firstmismatch = cur;

                    #define TRYSKIP(md, cd) \
                        if (match + md < curstart && \
                            cur   + cd < max      && \
                            tokens[match + md].name == tokens[cur + cd].name) \
                            { \
                                if (cur - lastfullmatchstart > biggestfullmatch) biggestfullmatch = cur - lastfullmatchstart; \
                                match += md - 1; \
                                cur += cd - 1; \
                                tokenskips += std::max(md, cd); \
                                lastfullmatchstart = cur; \
                                continue; \
                            }

                    TRYSKIP(1, 0);
                    TRYSKIP(0, 1);

                    TRYSKIP(1, 1);

                    TRYSKIP(2, 0);
                    TRYSKIP(0, 2);

                    TRYSKIP(1, 2);
                    TRYSKIP(2, 1);

                    TRYSKIP(2, 2);

                    break;
                }
            }

            if (!biggestfullmatch) biggestfullmatch = cur - curstart;

            if (tokenskips && (cur - curstart) / tokenskips < 7)
            {
                match -= cur - firstmismatch;
                cur = firstmismatch;
            }

            int len = cur - curstart;

            Token &a = tokens[curstart];
            Token &b = tokens[matchstart];

            double exponent = (decltokens * 2.2 + bodytokens * 2.6) / (decltokens + bodytokens);
            double bad = pow((len+len+biggestfullmatch-6) / 1.5 / log((double)(tokenskips+5)), exponent) / 13.5;    // badness depends on how skips are distributed, max a factor of 2 for evenly distributed compared to no skips
            int dist = abs(a.line - b.line);

            /*
            if (bad > 3000)
            {
                printf("%f %f %d %d\n", bad, exponent, decltokens, bodytokens);
            }
            */

            if (a.sf != b.sf) bad *= 1.7;     // cross file copy pasting is especially bad
            else if (dist<=1) bad *= 0.5;     // 2 adjacent copy pasted lines makes it easier to modify
            else if (dist<15) bad *= 0.8;     // always on same page

            if (bad > bestmatch.bad)
            {
                bestmatch.a = a;
                bestmatch.b = b;
                bestmatch.len = len;
                bestmatch.bad = bad;
                bestmatch.start = curstart;
                bestmatch.tokenskips = tokenskips;
            }

            match = matchstart; // try next token to see if we can find an even better match
            cur = curstart;
        }

        if (bestmatch.bad > 0.1)      // found at least 1 match
        {
            if (bestmatch.len > 2)
            {
                totalbad += bestmatch.bad;

                auto it = freqs.find(bestmatch.len);
                if (it == freqs.end()) freqs.insert(make_pair(bestmatch.len, make_pair(1, bestmatch.bad)));
                else { it->second.first++; it->second.second += bestmatch.bad; }

                if ((int)worst.size() < maxworst || worst[maxworst-1].bad<bestmatch.bad)
                {
                    int insertat = worst.size();
                    for (int i = 0; i<(int)worst.size(); i++) if (worst[i].bad<bestmatch.bad) { insertat = i; break; }
                    worst.insert(worst.begin() + insertat, bestmatch);
                    if ((int)worst.size() > maxworst) worst.resize(maxworst);
                }
            }

            cur += bestmatch.len;
        }
        else
        {
            cur++; // not even a single token was matched!
        }
    }

    wprintf(L"\n\ntime taken: %.1f seconds\n", (float) (btime() - starttime));

    // this is really only needed for magic formula tweaking
    
    wprintf(L"\nlengths:\n\n");
    for (auto it = freqs.begin(); it != freqs.end(); ++it) {
		const pair<int, pair<int, double> > &pr = *it;
        wprintf(L"len %d (%d occurrences): %.0f total sloppiness (%.2f%% of total)\n", pr.first, pr.second.first, pr.second.second, pr.second.second/totalbad*100.0);
    };
    

    wprintf(L"\nworst offenders:\n\n");
    for (auto it = worst.begin(); it != worst.end(); ++it) {
		Match &m = *it;
        wprintf(L"%d tokens & %d skips (%.0f sloppiness, %.2f%% of total) starting at:\n=> " WSTR_SPEC L":%d\n=> " WSTR_SPEC L":%d\n", m.len, m.tokenskips, m.bad, m.bad/totalbad*100.0, m.a.sf->fn.c_str(), m.a.line, m.b.sf->fn.c_str(), m.b.line);
        string sample = "";
        for (int i = m.start; i < m.start + m.len; i++)
        {
            if (i - m.start == 100) { sample += "<more follows...>"; break; }
            //if (tokens[i].isdecl)  sample += "@";
            sample += *tokens[i].name + " ";
        }
        printf("%s\n\n", sample.c_str());
    };

    wprintf(L"summary:\n\n");
    wprintf(L"total tokens: %d\n", tokens.size());
    wprintf(L"total sloppiness: %.0f\n", totalbad);
    wprintf(L"sloppiness / token ratio: %.2f\n", totalbad/tokens.size());

    wprintf(L"press enter to continue...\n");
    getchar();

	for (auto it = files.begin(); it != files.end(); ++it) delete *it;
	return 0;
}

#ifdef XUNIX
int main(int argc, char** argv)
{
	// convert the params to wchars:
	wchar_t** nargs = new wchar_t*[argc];
	for (int i = 0; i < argc; i++) {
		wstring x = convert_utf8_to_wide(argv[i]);
		nargs[i] = wcsdup(x.c_str());
	}
	int retval = _tmain(argc, nargs);
	for (int i = 0; i < argc; i++) free(nargs[i]);
	delete[] nargs;
	return retval;
}
#endif

// kate: tab-width 4