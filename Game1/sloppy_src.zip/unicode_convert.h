
// code taken from: http://www.linuxquestions.org/questions/programming-9/wstring-utf8-conversion-in-pure-c-701084/

void convert_wide_to_utf8(const wstring& input, char output[])
{
    int c = 0;
    for (size_t i = 0; i < input.size(); i++){
        wchar_t w = input[i];
        if (w <= 0x7f)
            output[c++] = (char)w;
        else if (w <= 0x7ff){
            output[c++] = (0xc0 | ((w >> 6)& 0x1f));
            output[c++] = (0x80| (w & 0x3f));
        }
        else if (w <= 0xffff){
            output[c++] = (0xe0 | ((w >> 12)& 0x0f));
            output[c++] = (0x80| ((w >> 6) & 0x3f));
            output[c++] = (0x80| (w & 0x3f));
        }
        else if (w <= 0x10ffff){
            output[c++] = (0xf0 | ((w >> 18)& 0x07));
            output[c++] = (0x80| ((w >> 12) & 0x3f));
            output[c++] = (0x80| ((w >> 6) & 0x3f));
            output[c++] = (0x80| (w & 0x3f));
        }
        else
            output[c++] = ('?');
    }
    output[c++] = 0;
}

wstring convert_utf8_to_wide(const char* input)
{
    wstring result;
    int l = (int) strlen(input), i = 0;
    while (i < l) {
        int x = input[i];
        if (x <= 0x7f) {
            result.push_back((wchar_t) x); 
            i++;
            continue;
        }
        int x1 = (i + 1 < l) ? input[i + 1] : 0;
        if (x < 0xe0) {
            result.push_back((wchar_t) (((x ^ 0xc0) << 6) | (x1 & 0x3f)));
            i += 2;
            continue;
        }
        int x2 = (i + 2 < l) ? input[i + 2] : 0;
        if (x < 0xf0) {
            result.push_back((wchar_t) (((x ^ 0xe0) << 12) | ((x1 & 0x3f) << 6) | (x2 & 0x3f)));
            i += 3;
            continue;
        }
        int x3 = (i + 3 < l) ? input[i + 3] : 0;
        result.push_back((wchar_t) (((x ^ 0xe0) << 18) | ((x1 & 0x3f) << 12) | ((x2 & 0x3f) << 6) | (x3 & 0x3f)));
        i += 4;
    }
    return result;
}

