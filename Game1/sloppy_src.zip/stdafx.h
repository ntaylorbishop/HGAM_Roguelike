#pragma once
#ifdef _WIN32
#define _CRT_SECURE_NO_WARNINGS

//#include "targetver.h"

#include <stdio.h>
#include <tchar.h>
#include <assert.h>

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <string>
#include <vector>
#include <map>
#include <stack>
#include <algorithm>

#define XWIN32

typedef unsigned char uchar;
#endif
